import Partner from "@/models/partner/partner.schema";

export default Partner;
